from fastapi import FastAPI, Form
from fastapi.responses import FileResponse, HTMLResponse
from video_maker import generate_video
from pathlib import Path

app = FastAPI()

@app.get('/', response_class=HTMLResponse)
def home():
    return Path('static/index.html').read_text()

@app.post('/generate')
def make_video(topic: str = Form(...)):
    out_file = generate_video(topic)
    return FileResponse(out_file, media_type='video/mp4', filename='ai_video.mp4')