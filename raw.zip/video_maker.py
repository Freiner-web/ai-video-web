import os, base64
from pathlib import Path
from moviepy.editor import ImageClip, concatenate_videoclips, AudioFileClip
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
assets = Path("/tmp/assets")
assets.mkdir(exist_ok=True)

def generate_video(topic: str) -> str:
    # Script
    script = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"user","content":f"Write a short 60-second video script about {topic}."}]
    ).choices[0].message.content.strip()

    # TTS
    audio_path = assets / "voice.mp3"
    with client.audio.speech.with_streaming_response.create(
        model="gpt-4o-mini-tts", voice="alloy", input=script
    ) as r:
        r.stream_to_file(audio_path)

    # Images (4 scenes)
    img_files = []
    for i, line in enumerate(script.split(".")[:4]):
        if line.strip():
            resp = client.images.generate(
                model="gpt-image-1", prompt=f"{topic}, {line}", size="1024x576"
            )
            img_b64 = resp.data[0].b64_json
            img_path = assets / f"scene_{i}.png"
            with open(img_path, "wb") as f_img:
                f_img.write(base64.b64decode(img_b64))
            img_files.append(img_path)

    # Assemble Video
    clips = [ImageClip(str(p)).set_duration(3) for p in img_files]
    video = concatenate_videoclips(clips, method="compose")
    audio = AudioFileClip(str(audio_path))
    video = video.set_audio(audio).set_duration(audio.duration)
    final_path = assets / "final_video.mp4"
    video.write_videofile(str(final_path), fps=24, codec="libx264")
    return str(final_path)